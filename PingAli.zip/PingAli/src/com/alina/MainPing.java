package com.alina;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import org.apache.log4j.Logger;



public class MainPing {
	
	final static Logger logger = Logger.getLogger(MainPing.class);
	
	public static void main(String[] args) {
		
		Util c = new Util();
		try {
			
			String hostList = c.getConfigProp("listHosts");
			String[] hostArr = hostList.split(",");
			//PrintWriter writer = new PrintWriter("src/jsonResponse.txt", "UTF-8"); 
			
			for (int i = 0; i < hostArr.length; i++) {				
				ThreadPing t = new ThreadPing(hostArr[i], 
						Long.parseLong(c.getConfigProp("delayTCP")), 
						Long.parseLong(c.getConfigProp("delayIMCP")), 
						Long.parseLong(c.getConfigProp("delayTracert")), 
						c.getConfigProp("pingTcpAtr"), c.getConfigProp("pingIcmpAtr"), 
						c.getConfigProp("tracertAtr"), hostArr[i], c.getConfigProp("sendUrl"), 
						new PrintWriter(new BufferedWriter(new FileWriter("src/jsonResponse.txt", true))));
				t.start();				
			}
		} catch (NumberFormatException | IOException e) {
			logger.error("Error in main :" + e.getMessage());
		}
		
	}
	
	
	

}
