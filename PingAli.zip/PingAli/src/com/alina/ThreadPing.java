package com.alina;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;
import org.icmp4j.IcmpPingRequest;
import org.icmp4j.IcmpPingResponse;
import org.icmp4j.IcmpPingUtil;
import org.json.JSONObject;

public class ThreadPing extends Thread{
	
	final static Logger logger = Logger.getLogger(ThreadPing.class);

	long delayTCP;
	long delayIMCP;
	long delayTracert;
	
	String pingTcpAtr = "";
	String pingIcmpAtr = "";
	String tracertAtr = "";
	
	String host = "";
	String name = "";
	
	String resultPingTCP = "";
	String resultPingICMP = "";
	String resultTracert = "";
	
	String sendUrl;
	PrintWriter writer;
	
	public ThreadPing(String name, long delayTCP, long delayIMCP, long delayTracert, String pingTcpAtr, String pingIcmpAtr, String tracertAtr, String host, String sendUrl, PrintWriter writer) {
		this.delayIMCP = delayIMCP;
		this.delayTCP = delayTCP;
		this.delayTracert = delayTracert;
		
		this.pingTcpAtr = pingTcpAtr;
		this.pingIcmpAtr = pingIcmpAtr;
		this.tracertAtr = tracertAtr;
		
		this.host = host;
		this.name = name;
		this.sendUrl = sendUrl;
		this.writer = writer;
		
	}
	
	public void run() {
		try {
			
			logger.info(" ----------------------- INIZIO Thread " + name + " Running" + "---------------------------------------" + " \n");
			int i = 0;
			while (true) {
				i++;
				JSONObject jsonObject = report(i, writer);
				sendJsonToURL(sendUrl, jsonObject.toString());
				
				if (i==2) {
					logger.info(" ----------------------- FINE Thread " + name + "---------------------------------------" + " \n" );
					break;					
				}
			}
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error in run :" + e.getMessage());
		}
		
	}
	
	public void sendJsonToURL(String sendUrl, String jsonString) {
		URL url;
		try {
			url = new URL(sendUrl);
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json; utf-8");
			//set Response Format Type
			con.setRequestProperty("Accept", "application/json");
			//to be able to write content to the connection output stream
			con.setDoOutput(true);
			
			//write
			String jsonInputString = jsonString;
			
			try(OutputStream os = con.getOutputStream()) {
			    byte[] input = jsonInputString.getBytes("utf-8");
			    os.write(input, 0, input.length);           
			}
			
			//Read the Response from Input Stream
			try(BufferedReader br = new BufferedReader(
					  new InputStreamReader(con.getInputStream(), "utf-8"))) {
					    StringBuilder response = new StringBuilder();
					    String responseLine = null;
					    while ((responseLine = br.readLine()) != null) {
					        response.append(responseLine.trim());
					    }
					    logger.info("\n Response URL :" + response.toString());
					}
		} catch (MalformedURLException e) {
			logger.error("Error in sendJsonToURL :" + e.getMessage());
		} catch (IOException e) {
			logger.error("Error in sendJsonToURL :" + e.getMessage());
		}

	}

	public String pingIcmp(int i, String host, String pingIcmpAtr, long delayIMCP) {
		try {
			// request
			final IcmpPingRequest request = IcmpPingUtil.createIcmpPingRequest();
			request.setHost(host);

			// delegate
			final IcmpPingResponse response = IcmpPingUtil.executePingRequest(request);
			// log
			final String formattedResponse = IcmpPingUtil.formatResponse(response);			
			
			logger.info("pingICMP "+ " ------  " + i + " ------  "  + host + "\n" + formattedResponse);
			
			Thread.sleep(delayIMCP);
			
			return formattedResponse;
			
		} catch (Exception e) {
			logger.error("Error in pingICMP :" + e.getMessage());
			return "ERROR - " + e.getMessage();
		}
	}
	
	public String pingTcpIp(int i, String host, String pingTcpAtr, long delayTCP) {

		String pingCmd = "ping " + pingTcpAtr + host;
		
		try {
			String pingResult = "";
			
			Runtime r = Runtime.getRuntime();
			Process p = r.exec(pingCmd);

			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				pingResult += inputLine;
			}
			
			in.close();
			logger.info("pingTCP-IP "+ " ------  " + i + " ------  "   + host + "\n" + pingResult);
			
			Thread.sleep(delayTCP);
			
			return pingResult;
			
		} catch (IOException e) {
			logger.error("Error- IOException in pingTCP-IP :" + e.getMessage());
			return "ERROR - " + e.getMessage();
		} catch (InterruptedException e) {
			logger.error("Error  InterruptedException in pingTCP-IP :" + e.getMessage());
			return "ERROR - " + e.getMessage();
		}
	}
	
	public String traceRt(int i, String host, String tracertAtr, long delayTracert) {
		
		String pingCmd = "tracert " + tracertAtr + host;
		
		try {
			String pingResult = "";
			Runtime r = Runtime.getRuntime();
			Process p = r.exec(pingCmd);

			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				pingResult += inputLine;
			}
		
			in.close();
			logger.info("traceRT " + " ------  " + i + " ------  " + host + "\n" + pingResult);
			
			Thread.sleep(delayTracert);
			
			return pingResult;
			
		} catch (IOException e) {
			logger.error("Error- IOException in traceRT :" + e.getMessage());
			return "ERROR - " + e.getMessage();
		} catch (InterruptedException e) {
			logger.error("Error  InterruptedException in traceRT :" + e.getMessage());
			return "ERROR - " + e.getMessage();
		}
	}
	
	public JSONObject report(int i, PrintWriter writer2) {
		resultPingICMP = pingIcmp(i, host, pingIcmpAtr, delayIMCP);
		resultPingTCP = pingTcpIp(i, host, pingTcpAtr, delayTCP);
		resultTracert = traceRt(i, host, tracertAtr, delayTracert);
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("host", host);
		jsonObject.put("icmp_ping", resultPingICMP);
		jsonObject.put("tcp_ping", resultPingTCP);
		jsonObject.put("trace", resultTracert);
		logger.info("\n \n Report : " + jsonObject.toString() + "\n\n");
		
		writer2.append(jsonObject.toString() + "\n\n");

		return jsonObject;
	}
}
