package com.alina;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

public class Util {
	
	final static Logger logger = Logger.getLogger(Util.class);

	public  String getConfigProp(String confProp) throws IOException {
		String result = "";
		InputStream inputStream = null;
		
		try {
			
			Properties prop = new Properties();
			String propFileName = "config.properties";
 
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
 
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
 
			Date time = new Date(System.currentTimeMillis());
 
			// get the property value and print it out
			result = prop.getProperty(confProp);
			logger.info("getConfigProp : " + confProp + " = " + result);
		} catch (Exception e) {
			logger.error("ERROR getConfigProp :" + e.getMessage());
		} finally {
			inputStream.close();
		}
		return result;
	}
}
